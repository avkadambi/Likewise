"""One module per screen."""
